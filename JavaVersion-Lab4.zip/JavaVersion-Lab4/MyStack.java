package implementation;

public class MyStack<E> {
	private MyArrayList<E> data;
	public MyStack() {
		data= new MyArrayList<E>();
	}
	
	public void push(E e) {
		data.add(e);
	}
	public E pop() {
		return data.remove(data.size()-1);
	}
	public E peek() {
		return data.get(data.size()-1);
	}
	public boolean empty() {
		return data.isEmpty();
	}
	public int search(E e) {
		return data.indexOf(e);
	}
	public String toString() {
		return "Stack: " + data.toString();
	}
}
