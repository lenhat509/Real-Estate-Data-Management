package implementation;

public class MyQueue<E> {
	private MyLinkedList<E> data;
	
	public MyQueue() {
		data = new MyLinkedList<E>();
	}
	
	public boolean offer(E e) {
		data.addLast(e);
		return true;
	}
	public E poll() {
		return data.remove(0);
	}
	public E remove() {
		return data.removeFirst();
	}
	public E peek() {
		return data.get(0);
	}
	public E element() {
		return data.getFirst();
	}
	@Override
	public String toString() {
		return "Queue: " +data.toString();
	}
}
