package implementation;

import java.util.Iterator;

public class MyLinkedList<E> extends MyAbstractList<E> {
	private Node<E> head, tail;
	
	
	public MyLinkedList() {
		head = null;
		tail = null;
	}
	public MyLinkedList(E[] list) {
		for(int i=0; i<list.length; i++)
			this.addLast(list[i]);
	}

	@Override
	public void add(int index, E e) {
		if(index==0)
			addFirst(e);
		else if(index==size)
			addLast(e);
		else
		{
			Node<E> current = new Node<E>();
			current = head;
			for(int i=0; i<index-1; i++)
				current = current.next;
			Node<E> newNode= new Node<E>(e, current.next);
			current.next= newNode;
			size++;
		}
		
	}

	@Override
	public void clear() {
		head= null;
		tail= null;
		size=0;
		
	}

	@Override
	public boolean contain(E e) {
		Node<E> current= new Node<E>();
		current = head;
		while(current!= null)
		{
			current= current.next;
			if (current.data.equals(e))
					return true;
		}
		return false;
	}

	@Override
	public E get(int index) {
		if(size>0)
		{
			Node<E> current = new Node<E>();
			current = head;
			for(int i=0; i<index; i++)
				current = current.next;
			return current.data;
		}
		return null;
	}

	@Override
	public int indexOf(E e) {
		if(size>0)
		{
			Node<E> current = new Node<E>();
			current = head;
			for(int i=0; i< size; i++)
			{
				if(current.data.equals(e))
					return i;
				current = current.next;
			}
			return -1;
		}
		return -1;
	}

	@Override
	public int lastIndexOf(E e) {
		if(size>0)
		{
			Node<E> current = new Node<E>();
			current = head;
			int tempPos= -1;
			for(int i=0; i< size; i++)
			{
				if(current.data.equals(e))
					tempPos=i;
				current = current.next;
			}
			return tempPos;
		}
		return -1;
	}

	@Override
	public E remove(int index) {
		if(size>0)
		{
			if(index==0)
				return removeFirst();
			else if(index==size-1)
				return removeLast();
			else
			{
				Node<E> current = head;
				for(int i= 0; i< index-1; i++)
					current= current.next;
				E e = current.next.data;
				current.next= current.next.next;
				size--;
				return e;
			}
		}
		return null;
	}

	@Override
	public E set(int index, E e) {
		Node<E> current = new Node<E>();
		current = head;
		for(int i=0; i< index; i++)
			current= current.next;
		E old = current.data;
		current.data= e;
		return old;
	}
	@Override
	public String toString() {
		Node<E> current= new Node<E>();
		current= head;
		String line= "[";
		while(current!=null)
		{
			if(current.next==null)
				line= line +current.data+ "]";
			else
				line= line +current.data+ ", ";
			current= current.next; 
		}
		return line;
	}
	
	public void addFirst(E e){
		Node<E> newNode= new Node<E>(e, head);
		head= newNode;
		size++;
		if(tail==null)
			tail=head;
	}
	public void addLast(E e){
		Node<E> newNode = new Node<E>();
		newNode.data= e;
		if(tail!=null)
			tail.next= newNode;
		tail = newNode;
		size++;
		if(head==null)
			head= tail;
	}
	public E removeFirst() {
		checkIndex(0);
		Node<E> temp= head;
		head= head.next;
		if(temp==tail)
			tail= head;
		size--;
		return temp.data;
	}	
	public E removeLast() {
		checkIndex(size-1);
		Node<E>parent= null;
		Node<E>current= head;
		while(current!=tail)
		{
			parent=current;
			current= current.next; 
		}
		E old= tail.data;
		tail = parent;
		if(parent!=null)
			parent.next= null;
		else
			head=tail;
		size--;
		return old;
	}
	public E getFirst() {
		checkIndex(0);
		return head.data;
	}
	public E getLast() {
		checkIndex(0);
		return tail.data;
	}
	@Override
	public Iterator<E> iterator() {
		return new MyIterator() ;
	}
	private class MyIterator implements Iterator<E> {
		private int current=0;
		@Override
		public boolean hasNext() {
			return current<size;
		}

		@Override
		public E next() {
			return MyLinkedList.this.get(current++);
		}
		@Override
		public void remove() {
			MyLinkedList.this.remove(current);
		}
		
	}
	private void checkIndex(int index) {
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException(index);
	}

}
