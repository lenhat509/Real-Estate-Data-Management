package implementation;

import java.util.Iterator;


public class MyArrayList<E> extends MyAbstractList<E> {
	private static final int DEFAULT= 16;
	private E data[]= (E[]) new Object[DEFAULT];
	
	public MyArrayList() {
		
	}
	public MyArrayList(E[] list) {
		for(int i=0; i< list.length; i++) 
			add(list[i]);
	}
	
	@Override
	public void add(int index, E e) {
		ensureCapacity();
		size++;
		checkIndex(index);
		for(int i = size-1; i>=index; i--)
			data[i+1]= data[i];
		data[index]= e;
		
	}
	
	private void ensureCapacity() {
		if(size == data.length) 
		{
			E newData[] = (E[]) new Object[size*2 +1];
			System.arraycopy(data, 0, newData, 0, size);
			data= newData;
		}
	}
	@Override
	public void clear() {
		data= (E[]) new Object[DEFAULT];
		size=0;
	}

	@Override
	public boolean contain(E e) {
		for(int i=0; i< size; i++)
			if(data[i].equals(e))
				return true;
		return false;
	}

	@Override
	public E get(int index) {
		checkIndex(index);
		return data[index];
	}
	private void checkIndex(int index) {
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException(index);
	}
	@Override
	public int indexOf(E e) {
		for(int i=0; i< size; i++)
			if(data[i].equals(e))
				return i;
		return -1;
	}

	@Override
	public int lastIndexOf(E e) {
		for(int i=size-1; i>=0; i--)
			if(data[i].equals(e))
				return i;
		return -1;
	}

	@Override
	public E remove(int index) {
		checkIndex(index);
		E e= data[index];
		for(int i=index; i<size-1;i++)
			data[i]=data[i+1];
		data[size-1] = null;
		size--;
		return e;
	}

	@Override
	public E set(int index, E e) {
		checkIndex(index);
		E old = data[index];
		data[index] = e;
		return old;
	}
	
	public void trimToSize() {
		if(size != data.length)
		{
			E newData[]= (E[]) new Object[size]; 
			System.arraycopy(data, 0, newData, 0, size);
			data = newData;
		}
	}
	@Override
	public String toString() {
		String array= "[";
		for(int i=0; i<size; i++) {
			if(i== (size-1))
				array = array + data[i]+ "]";
			else
				array = array + data[i]+ ", ";
		}
		return array;
	}
	@Override
	public Iterator<E> iterator() {
		return new MyIterator();
	}
	private class MyIterator implements Iterator<E>{
		private int current = 0;
		public boolean hasNext() {
			return (current< size);
		}
		@Override
		public E next() {
			if(hasNext())
				return data[current++];
			return null;
		}
		public void remove() {
			MyArrayList.this.remove(current);
		}
	}

}
