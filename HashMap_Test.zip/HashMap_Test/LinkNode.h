

#ifndef LINKNODE_H
#define LINKNODE_H

template<class T>
class LinkNode {
public:
    T data;
    LinkNode<T>* next;
    LinkNode();
};

template<class T>
LinkNode<T>::LinkNode() {
    next = nullptr;
}

//template<class T>
//LinkNode<T>::~LinkNode() {
//    /*deleteElement(data);*/
//    delete next;
//}

#endif

