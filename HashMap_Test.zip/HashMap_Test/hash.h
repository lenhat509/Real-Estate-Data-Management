#include <iostream>
#include <string>
#include "SinglyLinkedList.h"

// Node is housing object
class Node
{
public:
    std::string address;
    int price;
    int beds;
    int baths;
    std::string prop_type;
    int area;
	Node(){
		address = "";
		price = 0;
		beds = 0;
		baths = 0;
		prop_type = "";
		area = 0;
	}
	friend std::ostream& operator<<(std::ostream& out, const Node& obj) {
		out << "Address: " << obj.address << std::endl;
		out << "Price: " << obj.price << std::endl;
		out << "Beds: " << obj.beds << std::endl;
		out << "Baths: " << obj.baths << std::endl;
		out << "Prop_type: " << obj.prop_type << std::endl;
		out << "Area: " << obj.area << std::endl;
		return out;
	}
};

// entry is hash map item that contains key-value pair
class Entry {
public:
	std::string key;
	Node* value;
	Entry(const Entry& obj) {
		key = obj.key;
		value = nullptr;
		if (obj.value != nullptr)
		{
			value = new Node;
			*value = *(obj.value);
		}		
	}
	Entry() {
		key = "";
		value = nullptr;
	}
	Entry(std::string nKey, Node* nValue) {
		key = nKey;
		value = nullptr;
		if (nValue != nullptr)
		{
			value = new Node;
			*value = *nValue;
		}
	}
	Entry operator=(const Entry& obj) {
		if (this != &obj)
		{
			key = obj.key;
			if (value != nullptr)
				delete value;
			Node* nValue = new Node;
			*nValue = *(obj.value);
			value = nValue;
		}
		return *this;
	}
	bool operator==(const Entry& obj) {
		if (key.compare(obj.key) == 0)
			return true;
		return false;
	}
	bool operator!=(const Entry& obj) {
		if (key.compare(obj.key) != 0)
			return true;
		return false;
	}
	~Entry() {
		delete value;
		value = nullptr;
	}
	friend std::ostream& operator<<(std::ostream& out, const Entry& obj) {
		out << *(obj.value);
		return out;
	}
};

//This is hash map class
class Hash
{
private:
	const int DEFAULT_SIZE = 16;
	SinglyLinkedList<Entry>* hashTable;
	int size;
public:
		/*
			int hash(std::string key);
			get hash key
			Pre:	key.
			Post:	None.
			Return:	hash key
		*/
        int hash(std::string key);
		/*
			bool addItem(std::string key, Node* value);
			add item to hash table
			Pre:	std::string key, Node* value
			Post:	None.
			Return:	true if we successfully add object to table,
			false if the key already exists.
		*/
        bool addItem(std::string key, Node* value);
		/*
			bool removeItem(std::string key);
			remove item from hash table
			Pre:	std::string key
			Post:	None.
			Return:	true if we successfully remove object to table,
			false if the key does not exists in the table.
		*/
        bool removeItem(std::string key);
		/*
			Node getValue(std::string key);
			Get the housing object(value) that associated with the key
			Pre:	std::string key
			Post:	Node object(housing object)
			Return:	the housing object(node object) that associated with the key,
			if the key does not exists in the table return default node object.
		*/
		Node getValue(std::string key);
		/*
			bool find(std::string key);
			search for key in hash table
			Pre:	std::string key
			Post:	None.
			Return:	true if we find an object with matching key in the table ,
			false if the key does not exists in the table.
		*/
		bool find(std::string key);
		// print the whole table
        void printTable();
		// print the linked list at a specific index
		void printBucket(int index);
        // constructor 
        Hash();
        // destructor
        ~Hash();

};