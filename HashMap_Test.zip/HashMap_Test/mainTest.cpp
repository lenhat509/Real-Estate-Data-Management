#include "Parser.h"
#include <iostream>
#include <string>
#include <fstream>
#include "hash.h"
#include<cstdlib>
using namespace std;

/* 
	For CSV files, unless the headers are
	removed from the file, the data actually 
	starts on line 2.
*/

int main()
{
	int numData = 5;
	int numField = 6;
	
	Parser* csvInputParser = new Parser(numData, numField);

	ifstream csvFile;
	csvFile.open("db.csv");

	string inputStr;
	Hash hash;
	if (csvFile.is_open())
	{
		csvFile.ignore(255, '\n');
		for (int i = 0; i < csvInputParser->getNumData(); i++)
		{
			if (!getline(csvFile, inputStr))
			{
				inputStr = "";
			}
			csvInputParser->append(inputStr);
		}
		for (int i = 0; i < csvInputParser->getNumData(); i++)
		{
			Node* nNode = new Node;
			nNode->address = csvInputParser->getData(i)[0];
			nNode->price = stoi(csvInputParser->getData(i)[1]);
			nNode->beds = stoi(csvInputParser->getData(i)[2]);
			nNode->baths = stoi(csvInputParser->getData(i)[3]);
			nNode->prop_type = csvInputParser->getData(i)[4];
			nNode->area = stoi(csvInputParser->getData(i)[5]);
			hash.addItem(nNode->address, nNode);
		}
		cout <<"Is there '6252 Mahan Dr' key in table: "<<hash.find("6252 Mahan Dr") << endl;
		cout <<"Remove object with key '6252 Mahan Dr': " << hash.removeItem("6252 Mahan Dr") << endl;
		cout <<"Is there '6252 Mahan Dr' key in table : "<< hash.find("6252 Mahan Dr") << endl;
		cout << "Remove object with key '1560 McKendrie St': " << hash.removeItem("1560 McKendrie St") << endl;
		cout << "Remove object with key '1560 McKendrie St': " << hash.removeItem("1560 McKendrie St") << endl;
		cout << "Get value with the key '309 Tradewinds Dr Apt 2' :" << endl << (hash.getValue("309 Tradewinds Dr Apt 2")) << endl;
	}
	else
	{
		cout << "File not found." << endl;
	}
	//print all the hash table
	cout<<"--------------"<<endl;
	hash.printTable();

	return 0;
}