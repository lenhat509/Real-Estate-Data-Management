#include <iostream>
#include <string>
#include "hash.h"

int Hash::hash(std::string key)
{
    // get int value of key
    int hash_value = key.length();
    // return hash_value mod tablesize to get our hash key
    return hash_value % DEFAULT_SIZE;
}
bool Hash::addItem(std::string key, Node* value)
{
    // get hash Key
    int index = hash(key);
    if (hashTable == nullptr)
        hashTable = new SinglyLinkedList<Entry>[DEFAULT_SIZE];
    // make table entry
    Entry nEntry(key, value);
    if (hashTable[index].find(nEntry))
        return false;
    else
        hashTable[index].append(nEntry);
    size++;
    return true;
    
}
bool Hash::removeItem(std::string key)
{
    // get hash key
    int index = hash(key);
    Entry nEntry(key, nullptr);
    if (hashTable[index].remove(nEntry))
    {
        size--;
        return true;
    }
    return false;
}
bool Hash::find(std::string key) {
    int index = hash(key);
    Entry nEntry(key, nullptr);
    if (hashTable[index].find(nEntry))
        return true;
    return false;
}
Node Hash::getValue(std::string key) {
    int index = hash(key);
    for (int i = 0; i < hashTable[index].getCount(); i++)
    {
        if (hashTable[index].getAt(i).key.compare(key) == 0)
             return *hashTable[index].getAt(i).value;
    }
    return Node();
}
void Hash::printTable() {
    for (int i = 0; i < DEFAULT_SIZE; i++)
    {
        if (!hashTable[i].isEmpty())
            hashTable[i].printList();
    }
}
void Hash::printBucket(int index) {
    if (index >= 0 && index < DEFAULT_SIZE)
    {
        hashTable[index].printList();
    }
}
// constructor 
Hash::Hash()
{
    size = 0;
    hashTable = nullptr;
}
//destructor 
Hash::~Hash()
{
    delete []hashTable;
    hashTable = nullptr;
}