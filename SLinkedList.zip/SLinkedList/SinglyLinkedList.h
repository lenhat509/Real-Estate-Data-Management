/*
March, 12th, 2020
For this assignment we will be creating a multi-file project
in which we implement our own templated linked list and
use it to create a simple list of composers
*/
#ifndef SINGLYLINKEDLIST_H
#define SINGLYLINKEDLIST_H
#include<iostream>
#include "LinkNode.h"
using namespace std;


template<class T>
class SinglyLinkedList {
private:
	LinkNode<T>* start;
	LinkNode<T>* end;
	int count;
public:
	SinglyLinkedList();
	~SinglyLinkedList();
	void printList() const;
	void append(const T data);
	void prepend(const T data);
	bool removeFront();
	void insert(const T data, int index);
	bool remove(const T data);
	bool find(const T data);
	bool isEmpty() const;
	T getFirst() const;
	T getLast() const;
	int size();
	void clear();
};
// default constructor
template<class T>
SinglyLinkedList<T>::SinglyLinkedList() {
	start = end = nullptr;
	count = 0;
}
template<class T>
int SinglyLinkedList<T>::size() {
	return count;
}
template<class T>
void SinglyLinkedList<T>::clear() {
	bool check = true;
	while (check)
		check = removeFront();
	count = 0;
}
//destructor
template<class T>
SinglyLinkedList<T>::~SinglyLinkedList() {
	clear();
}
/*
1. This method accept nothing
2. It return nothing
3. It displays every LinkNode in linked list in ascending order
*/
template<class T>
void SinglyLinkedList<T>::printList() const {
	if (start != nullptr)
	{
		LinkNode<T>* current = start;
		while (current != nullptr)
		{
			cout << current->data << endl;
			current = current->next;
		}
	}
}
/*
1. This method accept T object
2. It return nothing
3. It add a new LinkNode at the end of linked list
*/
template<class T>
void SinglyLinkedList<T>::append(const T data) {
	LinkNode<T>* newLinkNode = new LinkNode<T>();
	newLinkNode->data = data;
	if (end != nullptr)
		end->next = newLinkNode;
	end = newLinkNode;
	if (start == nullptr)
		start = end;
	count++;
}
/*
1. This method accept T object
2. It return nothing
3. It add a new LinkNode at the beginning of linked list
*/
template<class T>
void SinglyLinkedList<T>::prepend(const T data)
{
	LinkNode<T>* newLinkNode = new LinkNode<T>();
	newLinkNode->data = data;
	newLinkNode->next = start;
	start = newLinkNode;
	if (end == nullptr)
		end = start;
	count++;
}
/*
1. This method accept nothing
2. It return true/false
3. It remove a LinkNode at the beginning of linked list
*/
template<class T>
bool SinglyLinkedList<T>::removeFront()
{
	if (start != nullptr)
	{
		LinkNode<T>* temp = start;
		start = start->next;
		if (end == temp)
			end = start;
		delete temp;
		count--;
		return true;
	}
	else
		return false;
}
/*
1. This method accept T object
2. It return nothing
3. It adds a new LinkNode to linked list in the correct order
*/
template<class T>
void SinglyLinkedList<T>::insert(const T data, int index) {
	if (count>=index && index >=0)
	{
		LinkNode<T>* current = start;
		LinkNode<T>* previous = nullptr;
		int curPosition = 0;
		while (curPosition != index)
		{
			previous = current;
			current = current->next;
			curPosition++;
		}
		if (current == nullptr)
			append(data);
		else
		{
			if (previous == nullptr)
				prepend(data);
			else
			{
				LinkNode<T>* newLinkNode = new LinkNode<T>();
				newLinkNode->data = data;
				previous->next = newLinkNode;
				newLinkNode->next = current;
				count++;
			}
		}
	}
}
/*
1. This method accept T object
2. It return true/false
3. It remove a LinkNode in linked list
*/
template<class T>
bool SinglyLinkedList<T>::remove(const T data) {
	LinkNode<T>* current = start;
	LinkNode<T>* previous = nullptr;
	while (current != nullptr)
	{
		if (current->data == data)
			break;
		previous = current;
		current = current->next;
	}
	if (current == nullptr)
		return false;
	else
	{
		if (previous == nullptr)
			return removeFront();
		else
		{
			previous->next = current->next;
			if (current == end)
				end = previous;
			delete current;
			count--;
			return true;
		}
	}
	return false;
}
/*
1. This method accept T object
2. It return true/false
3. It checks whether a LinkNode exists in linked list
*/
template<class T>
bool SinglyLinkedList<T>::find(const T data) {
	LinkNode<T>* current = start;
	while (current != nullptr)
	{
		if (current->data == data)
			return true;
		current = current->next;
	}
	return false;
}
/*
1. This method accept nothing
2. It return true/false
3. It checks whether a linked list is empty
*/
template<class T>
bool SinglyLinkedList<T>::isEmpty() const {
	return count==0;
}
/*
1. This method accept nothing
2. It returns T object
3. It returns the first LinkNode in the linked list
*/
template<class T>
T SinglyLinkedList<T>::getFirst() const {
	if (start != nullptr)
		return start->data;
	return T();
}
/*
1. This method accept nothing
2. It returns T object
3. It returns the last LinkNode in the linked list
*/
template<class T>
T SinglyLinkedList<T>::getLast() const {
	if (end != nullptr)
		return end->data;
	return T();
}
#endif 



