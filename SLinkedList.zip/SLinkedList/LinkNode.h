/*
March, 12th, 2020
For this assignment we will be creating a multi-file project
in which we implement our own templated linked list and
use it to create a simple list of composers
*/
#ifndef LINKNODE_H
#define LINKNODE_H
template<class T>
class LinkNode {
public:
	T data;
	LinkNode<T>* next;
	LinkNode();
};
//default constructor
template<class T>
LinkNode<T>::LinkNode() {
	next = nullptr;
}
#endif 

