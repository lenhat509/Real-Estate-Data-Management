#ifndef LINKNODE_H_
#define LINKNODE_H_

template<typename T>
class LinkNode
{
	public:
		T data;
		LinkNode<T>* next;
		LinkNode();
};

template<typename T>
LinkNode<T>::LinkNode()
{
	data = T();
	next = nullptr;
}


#endif