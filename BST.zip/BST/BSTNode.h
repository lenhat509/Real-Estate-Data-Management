#ifndef BSTNODE_H
#define BSTNODE_H
template<typename T>
class BSTNode {
private:
	T data;
	BSTNode<T>* leftChild;
	BSTNode<T>* rightChild;
public:
	BSTNode() {
		leftChild = nullptr;
		rightChild = nullptr;
	}
	T getData() {
		return data;
	}
	void setData(const T& nData)
	{
		data = nData;
	}
	BSTNode<T>* getLeftChild() {
		return leftChild;
	}
	void setLeftChild(BSTNode<T>* left)
	{
		leftChild = left;
	}
	BSTNode<T>* getRightChild() {
		return rightChild;
	}
	void setRightChild(BSTNode<T>* right)
	{
		rightChild = right;
	}
};
#endif // !BSTNODE_H

