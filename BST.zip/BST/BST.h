#ifndef BST_H
#define BST_H
#include "BSTNode.h"
#include "Queue.h"
#include<iostream>
template<typename T>
class BST {
private:
	BSTNode<T>* root;
	int size;
public:
	BST();
	~BST() {
		empty();
	}
	void insert(const T);
	bool search(const T);
	void remove(const T);
	void print();
	int count() {
		return size;
	}
	bool isEmpty() {
		return size == 0;
	}
	void empty();
	void breadthFirst(BSTNode<T>* node);
	void inOrder(BSTNode<T>* node);
	void preOrder(BSTNode<T>* node);
	void postOrder(BSTNode<T>* node);
};
template<typename T>
BST<T>::BST() {
	root = nullptr;
	size = 0;
}
template<typename T>
void BST<T>::insert(const T data) {
	if (root != nullptr)
	{
		BSTNode<T>* curParent = nullptr;
		BSTNode<T>* current = root;
		while (current != nullptr)
		{
			if (current->getData() < data)
			{
				curParent = current;
				current = current->getRightChild();
			}
			else if (current->getData() > data)
			{
				curParent = current;
				current = current->getLeftChild();
			}
			else
				return;
		}
		BSTNode<T>* newNode = new BSTNode<T>();
		newNode->setData(data);
		if (curParent->getData() < data)
			curParent->setRightChild(newNode);
		else
			curParent->setLeftChild(newNode);
		size++;
	}
	else {
		root = new BSTNode<T>();
		root->setData(data);
		size++;
	}
}
template<typename T>
void BST<T>::remove(const T data)
{
	if (root != nullptr)
	{
		BSTNode<T>* curParent = nullptr;
		BSTNode<T>* current = root;
		while (current != nullptr)
		{
			if (current->getData() < data)
			{
				curParent = current;
				current = current->getRightChild();
			}
			else if (current->getData() > data)
			{
				curParent = current;
				current = current->getLeftChild();
			}
			else
				break;
		}
		if (current == nullptr)
			return;
		if (current->getLeftChild() == nullptr)
		{
			if (curParent != nullptr)
			{
				if (curParent->getData() < current->getData())
					curParent->setRightChild(current->getRightChild());
				else
					curParent->setLeftChild(current->getRightChild());
				delete current;
				size--;
			}
			else
			{
				BSTNode<T>* oldRoot = root;
				root = root->getRightChild();
				delete oldRoot;
				size--;
			}
		}
		else
		{
			BSTNode<T>* max = current->getLeftChild();
			BSTNode<T>* maxParent = current;
			while (max->getRightChild())
			{
				maxParent = max;
				max = max->getRightChild();
			}
			current->setData(max->getData());
			if (max->getData() > maxParent->getData())
				maxParent->setRightChild(max->getLeftChild());
			else
				maxParent->setLeftChild(max->getLeftChild());
			delete max;
			size--;
		}
	}
}
template<typename T>
bool BST<T>::search(const T data) {
	if (root != nullptr)
	{
		BSTNode<T>* current = root;
		while (current != nullptr)
		{
			if (current->getData() < data)
				current = current->getRightChild();
			else if (current->getData() > data)
				current = current->getLeftChild();
			else
				return true;
		}
	}
	return false;
}
template<typename T>
void BST<T>::inOrder(BSTNode<T>* node) {
	if (node != nullptr)
	{
		inOrder(node->getLeftChild());
		std::cout << node->getData() << " ";
		inOrder(node->getRightChild());
	}
}
template<typename T>
void BST<T>::preOrder(BSTNode<T>* node){
	if (node != nullptr)
	{
		std::cout << node->getData() << " ";
		preOrder(node->getLeftChild());
		preOrder(node->getRightChild());
	}
}
template<typename T>
void BST<T>::postOrder(BSTNode<T>* node) {
	if (node != nullptr)
	{
		postOrder(node->getLeftChild());
		postOrder(node->getRightChild());
		std::cout << node->getData() << " ";
	}
}
template<typename T>
void BST<T>::breadthFirst(BSTNode<T>* node){
	Queue<BSTNode<T>*> queue;
	while (node != nullptr)
	{
		std::cout << node->getData() << " ";
		if (node->getLeftChild())
			queue.enqueue(node->getLeftChild());
		if (node->getRightChild())
			queue.enqueue(node->getRightChild());
		if (queue.peekFront() != nullptr)
		{
			node = queue.peekFront();
			queue.dequeue();
		}
		else
			node = nullptr;
	}
}
template<typename T>
void BST<T>::empty() {
	while (!isEmpty())
		remove(root->getData());
}
template<typename T>
void BST<T>::print() {
	std::cout <<"Breadth-first traversal: "<< std::endl;
	breadthFirst(root);
	std::cout << std::endl;
	std::cout << "Pre-order traversal: " << std::endl;
	preOrder(root);
	std::cout << std::endl;
	std::cout << "In-order traversal: " << std::endl;
	inOrder(root);
	std::cout << std::endl;
	std::cout << "Post-order traversal: " << std::endl;
	postOrder(root);
	std::cout << std::endl;
}
#endif // !BST_H

