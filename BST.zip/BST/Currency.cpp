/*
 Lab Number: 04
 Group members: Nguyen Cong Nhat Le, Kevin Jin
 Name: Nguyen Cong Nhat Le
 Description:
 The assignment is to demonstrate the use of a defined templated linked list, stack, and
 queue of integers with all methods of the ADTs through the console.

  Grade Kevin's effort: HIGH
*/

#include <string>
#include <cstdlib>
#include "Currency.h"

/*
 This method rolls fractional parts into whole parts.
 Pre    access to protected attributes whole and fraction
 Post   whole is incremented for every 100 of fraction while fraction is mod 100
*/
void Currency::simplify() {
    fraction += whole * 100;
    whole = fraction / 100;
    fraction -= whole * 100;
}

/*
 This method overloads the + operator.
 Pre    operands to the left and right of the operator are Currency objects
 Post   the temp Currency object containing the value from addition is returned
*/
Currency Currency::operator + (Currency &right) {
    Currency temp = Currency(whole + right.whole, fraction + right.fraction);
    
    temp.simplify();
    return temp;
}

/*
 This method overloads the - operator.
 Pre    operands to the left and right of the operator are Currency objects
 Post   the temp Currency object containing the value from subtraction is returned
*/
Currency Currency::operator - (Currency &right) {
    Currency temp = Currency(whole - right.whole, fraction - right.fraction);
    
    temp.simplify();
    return temp;
}

/*
 This method overloads the > operator.
 Pre    operands to the left and right of the operator are Currency objects
 Post   status containing true or false is returned
*/
bool Currency::operator > (const Currency &right) {
    bool status;
    
    if (whole > right.whole)
        status = true;
    else if (whole == right.whole && fraction > right.fraction)
        status = true;
    else
        status = false;
    
    return status;
}

/*
 This method overloads the < operator.
 Pre    operands to the left and right of the operator are Currency objects
 Post   status containing true or false is returned
*/
bool Currency::operator < (const Currency &right) {
    bool status;
    
    if (whole < right.whole)
        status = true;
    else if (whole == right.whole && fraction < right.fraction)
        status = true;
    else
        status = false;
        
    return status;
}

// TODO: >> operator overload only used when given child objects.
/*
 This method overloads the >> operator.
 Pre    left operand is an istream object and right operand is a Currency object
 Post   assigns values from input into the Currency object and returns the istream object
*/
/*
std::istream& operator >> (std::istream &input, Currency *&curr) {  // *&curr is the address of a pointer of curr
    std::string note, coin;
    int whole, fraction;
    
    input >> note >> whole >> fraction >> coin;
    
    // capitalizes the beginning character of the note string if not done so
    if (note[0] >= 'a')
        note[0] += 'A' - 'a';
        
    if (note == "Dollar" && coin == "cent")
        curr = new Dollar(whole, fraction);
    if (note == "Pound" && coin == "pence")
        curr = new Pound(whole, fraction);
    if (note == "Yen" && coin == "sen")
        curr = new Yen(whole, fraction);
    if (note == "Rupee" && coin == "paise")
        curr = new Rupee(whole, fraction);
    if (note == "Real" && coin == "centavo")
        curr = new Real(whole, fraction);

    return input;
}
*/

/*
 This method overloads the << operator.
 Pre    left operand is an istream object and right operand is a Currency object
 Post   assigns values from Currency object into an ostream object and returns it
*/
std::ostream& operator << (std::ostream &output, const Currency &curr) {
    output << curr.getNote() << " " << curr.getWhole() << " " << curr.getFraction() << " " << curr.getCoin();
    
    return output;
}

// TODO: If the header is:
// std::ostream& operator << (std::ostream &output, Currency curr) {
// - b/c the curr isn't passed by reference, the copy of the object is of Currency type, meaning that
//   if curr was initialized to a child object like Dollar, the note and coin is sliced off

// std::ostream& operator << (std::ostream &output, Currency &curr) {
// - b/c the curr is passed by reference if the output statement is:
// cout << *pDollar << endl; vs cout << pDollar
//   the first cout << *pDollar statement works
