#include<iostream>
#include<fstream>
#include "BST.h"
#include "Currency.h"

using namespace std;

int main() {
	//test here
	BST<Currency> tree;
	Currency obj1(12, 63);
	Currency obj2(2, 6);
	Currency obj3(23, 63);
	Currency obj4(12, 50);
	Currency obj5(7, 3);
	Currency obj6(92, 30);
	Currency obj7(0, 6);
	Currency obj8(7, 34);
	Currency obj9(32, 6);
	Currency obj10(20, 66);
	tree.insert(obj1);
	tree.insert(obj2);
	tree.insert(obj3);
	tree.insert(obj4);
	tree.insert(obj5);
	tree.insert(obj6);
	tree.insert(obj7);
	tree.insert(obj8);
	tree.insert(obj9);
	tree.insert(obj10);
	cout << "Search obj1: " << tree.search(obj1) << endl;
	cout << "Is empty: " << tree.isEmpty() << endl;
	cout << "Count " << tree.count() << endl;
	tree.print();
	tree.remove(obj1);
	cout << "Search obj1: " << tree.search(obj1) << endl;
	cout << "Is empty: " << tree.isEmpty() << endl;
	cout << "Count " << tree.count() << endl;
	tree.print();
	tree.remove(obj2);
	tree.remove(obj3);
	tree.remove(obj4);
	tree.remove(obj5);
	tree.remove(obj6);
	tree.remove(obj7);
	tree.remove(obj10);
	cout << "Search obj9: " << tree.search(obj9) << endl;
	cout << "Is empty: " << tree.isEmpty() << endl;
	cout << "Count " << tree.count() << endl;
	tree.print();
	tree.empty();
	cout << "Search obj9: " << tree.search(obj9) << endl;
	cout << "Is empty: " << tree.isEmpty() << endl;
	cout << "Count " << tree.count() << endl;
}
	
		//BST<int> tree;
		//tree.insert(21);
		//tree.insert(11);
		//tree.insert(1);
		//tree.insert(7);
		//tree.insert(21);
		//tree.insert(18);
		//tree.insert(4);
		//tree.insert(25);
		//tree.insert(22);
		//cout << "Search 21: " << tree.search(21) << endl;
		//cout << "Is empty: " << tree.isEmpty() << endl;
		//cout << "Count " << tree.count() << endl;
		//tree.remove(21);
		//cout << "Search 21: " << tree.search(21) << endl;
		//tree.print();
		//tree.remove(11);
		//tree.print();
		///*tree.remove(1);
		//tree.print();
		//tree.remove(7);
		//tree.print();
		//tree.remove(21);
		//tree.print();*/
		//tree.remove(18);
		//tree.print();
		//cout << "Search 4: " << tree.search(4) << endl;
		//cout << "Is empty: " << tree.isEmpty() << endl;
		//cout << "Count " << tree.count() << endl;
		//tree.remove(4);
		//cout << "Search 4: " << tree.search(4) << endl;
		//cout << "Is empty: " << tree.isEmpty() << endl;
		//cout << "Count " << tree.count() << endl;
		//tree.empty();
		//cout << "Search 1: " << tree.search(1) << endl;
		//cout << "Is empty: " << tree.isEmpty() << endl;
		//cout << "Count " << tree.count() << endl;
		//tree.print();