/*
 Lab Number: 04
 Group members: Nguyen Cong Nhat Le, Kevin Jin
 Name: Nguyen Cong Nhat Le
 Description:
 The assignment is to demonstrate the use of a defined templated linked list, stack, and
 queue of integers with all methods of the ADTs through the console.

  Grade Kevin's effort: HIGH
*/

#ifndef CURRENCY_H
#define CURRENCY_H
#include <cstdlib>
#include <string>
#include <iostream>

class Currency {
protected:
    int whole, fraction;
    
    // protected function prototype
    void simplify();
public:
    /*
     This method is a default constructor of the Currency class.
     Pre    None
     Post   a base Currency object with whole and fraction values of 0 is initialized
     Return None
     */
    Currency() {
        whole = 0;
        fraction = 0;
    }
    
    /*
     This method is a constructor of the Currency class.
     Pre    w - whole value passed by reference
            f - fraction value passed by reference
     Post   a base Currency object with a whole value of w and a fraction value of f is
            initialized
     Return None
     */
    Currency(int w, int f) : whole(w), fraction(f) {}
    
    /*
     This method is an accessor function returning value of the whole attribute.
     Pre    None
     Post   whole - the Currency object's note value
     */
    int getWhole() const {
        return whole;
    }
    
    /*
     This method is an accessor function returning value of the fraction attribute.
     Pre    None
     Post   fraction - the Currency object's fraction value
     */
    int getFraction() const {
        return fraction;
    }
    
    /*
     This method is a mutator function assigning a value to the whole attribute.
     Pre    w - whole value passed by reference
     Post   the whole attribute is set to w
    */
    void setWhole(int w) {
        whole = w;
    }
    
    /*
     This method is a mutator function assinging a value to the whole attribute.
     Pre    f - fraction value passed by reference
     Post   the fraction attribute is set to f
    */
    void setFraction(int f) {
        fraction = f;
    }

    /*
     This method returns an empty string because Currency objects do not have a note
     attribute.
     Pre    None
     Post   an empty string ("") is returned
     */
    virtual std::string getNote() const {
        return "";
    }
    
    /*
    This method returns an empty string because Currency objects do not have a coin
    attribute.
    Pre    None
    Post   an empty string ("") is returned
    */
    virtual std::string getCoin() const {
        return "";
    }

    // prototypes for virtual functions
    virtual Currency operator + (Currency &);
    virtual Currency operator - (Currency &);
    virtual bool operator < (const Currency &);
    virtual bool operator > (const Currency &);
    
    // prototypes for i/o stream functions
    friend std::ostream& operator << (std::ostream &output,  const Currency &c);
    friend std::istream& operator >> (std::istream &input, Currency *&c);
};

#endif /* currency_h */
