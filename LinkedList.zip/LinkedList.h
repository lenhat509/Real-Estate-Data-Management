/*
March, 12th, 2020
For this assignment we will be creating a multi-file project
in which we implement our own templated linked list and
use it to create a simple list of composers
*/
#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include<iostream>
#include "Node.h"
using namespace std;

template<class T>
class LinkedList {
private:
	Node<T>* head;
	Node<T>* tail;
public:
	LinkedList();
	~LinkedList();
	void printList() const;
	void append(const T data);
	void prepend(const T data);
	bool removeFront();
	void insert(const T date);
	bool remove(const T data);
	bool find(const T data);
	bool isEmpty() const;
	T getFirst() const;
	T getLast() const;
};
// default constructor
template<class T>
LinkedList<T>::LinkedList() {
	head = tail = nullptr;
}
//destructor
template<class T>
LinkedList<T>::~LinkedList() {
	bool check = true;
	while (check)
		check = removeFront();
}
/*
1. This method accept nothing
2. It return nothing
3. It displays every node in linked list in ascending order
*/
template<class T>
void LinkedList<T>::printList() const {
	if (head != nullptr)
	{
		Node<T>* current = head;
		while (current != nullptr)
		{
			cout << current->value<<endl;
			current = current->next;
		}
	}
}
/*
1. This method accept T object
2. It return nothing
3. It add a new node at the end of linked list 
*/
template<class T>
void LinkedList<T>::append(const T data) {
	Node<T>* newNode = new Node<T>();
	newNode->value = data;
	if (tail != nullptr)
		tail->next = newNode;
	tail = newNode;
	if(head==nullptr)
		head = tail;
}
/*
1. This method accept T object
2. It return nothing
3. It add a new node at the beginning of linked list
*/
template<class T>
void LinkedList<T>::prepend(const T data)
{
	Node<T>* newNode = new Node<T>();
	newNode->value = data;
	newNode->next = head;
	head = newNode;
	if(tail== nullptr)
		tail = head;
}
/*
1. This method accept nothing
2. It return true/false
3. It remove a node at the beginning of linked list
*/
template<class T>
bool LinkedList<T>::removeFront() 
{
	if (head != nullptr)
	{
		Node<T>* temp = head;
		head = head->next;
		if (tail == temp)
			tail = head;
		delete temp;
		return true;
	}
	else
		return false;
}
/*
1. This method accept T object
2. It return nothing
3. It adds a new node to linked list in the correct order
*/
template<class T>
void LinkedList<T>::insert(const T data) {
	if (head != nullptr)
	{
		Node<T>* current = head;
		Node<T>* previous = nullptr;
		while (current != nullptr)
		{
			if (current->value > data)
				break;
			previous = current;
			current = current->next;
		}
		if (current == nullptr)
			append(data);
		else
		{
			if (previous == nullptr)
				prepend(data);
			else
			{
				Node<T>* newNode = new Node<T>();
				newNode->value = data;
				previous->next = newNode;
				newNode->next = current;
			}
		}
	}
	else
		prepend(data);
}
/*
1. This method accept T object
2. It return true/false
3. It remove a node in linked list
*/
template<class T>
bool LinkedList<T>::remove(const T data) {
	Node<T>* current = head;
	Node<T>* previous = nullptr;
	while (current != nullptr)
	{
		if (current->value == data)
			break;
		previous = current;
		current = current->next;
	}
	if (current == nullptr)
		return false;
	else
	{
		if (previous == nullptr)
			return removeFront();
		else 
		{
			previous->next = current->next;
			if (current == tail)
				tail = previous;
			delete current;
			return true;
		}
	}
	return false;
}
/*
1. This method accept T object
2. It return true/false
3. It checks whether a node exists in linked list
*/
template<class T>
bool LinkedList<T>::find(const T data) {
	Node<T>* current = head;
	while (current != nullptr)
	{
		if (current->value == data)
			return true;
		current = current->next;
	}
	return false;
}
/*
1. This method accept nothing
2. It return true/false
3. It checks whether a linked list is empty
*/
template<class T>
bool LinkedList<T>::isEmpty() const {
	return (head == nullptr);
}
/*
1. This method accept nothing
2. It returns T object
3. It returns the first node in the linked list
*/
template<class T>
T LinkedList<T>::getFirst() const{
	if (head != nullptr)
		return head->value;
	return T();
}
/*
1. This method accept nothing
2. It returns T object
3. It returns the last node in the linked list
*/
template<class T>
T LinkedList<T>::getLast() const {
	if (tail!= nullptr)
		return tail->value;
	return T();
}
#endif 



