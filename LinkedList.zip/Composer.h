/*
March, 12th, 2020
For this assignment we will be creating a multi-file project
in which we implement our own templated linked list and
use it to create a simple list of composers
*/
#ifndef COMPOSER_H
#define COMPOSER_H
#include<string>
#include<ostream>
using namespace std;
class Composer {
private:
	string name;
	int year;
public:
	Composer();
	Composer(string, int);
	friend ostream& operator<<(ostream&, const Composer&);
	bool operator== (const Composer&);
	bool operator>(const Composer&);
};
#endif 

