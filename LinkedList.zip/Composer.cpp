/*
March, 12th, 2020
For this assignment we will be creating a multi-file project
in which we implement our own templated linked list and
use it to create a simple list of composers
*/
#include "Composer.h"
#include<string>
#include<ostream>
//default constructor
Composer::Composer() {
	name = "";
	year = 0;
}
//overloaded constructor
Composer::Composer(string n, int y) {
	name = n;
	year = y;
}
/*
1. This method accepts a reference of Composer object
2. It returns true/ false
3. It overloads the '==' operator
*/
bool Composer::operator==(const Composer& obj) {
	return (name.compare(obj.name)==0);
}
/*
1. This method accepts a reference of Composer object
2. It returns true/ false
3. It overloads the '>' operator
*/
bool Composer::operator>(const Composer& obj) {
	return (year > obj.year);
}
/*
1. This method accepts references of Composer and ostream objects
2. It returns reference of ostream object
3. It overloads the '<<' operator
*/
ostream& operator<<(ostream& out, const Composer& obj)
{
	out << obj.name << " - " << obj.year;
	return out;
}
