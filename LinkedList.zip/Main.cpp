/*
March, 12th, 2020
For this assignment we will be creating a multi-file project 
in which we implement our own templated linked list and 
use it to create a simple list of composers
*/
#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>
#include<string>
#include "Composer.h"
#include "LinkedList.h"

using namespace std;

void populatedFromFile(fstream&, LinkedList<Composer>&);
bool options(LinkedList<Composer>&);
void search(LinkedList<Composer>&);
void remove(LinkedList<Composer>&);	

int main() {
	fstream file;
	LinkedList<Composer> list;
	populatedFromFile(file, list);
	bool check = true;
	while (check)
	{
		check = options(list);
	}
	return 0;
}
/*
1. This method accepts references of fstream and LinkedList objects
2. It returns nothing
3. It populates datum from a text file to LinkedList
*/
void populatedFromFile(fstream& inFile, LinkedList<Composer>& list) 
{
	inFile.open("composers.txt", ios::in);
	if (inFile)
	{
		while (!inFile.eof())
		{
			string name = "";
			getline(inFile, name, ',');
			inFile.ignore();
			string yearStr = "";
			getline(inFile, yearStr);
			int year = stoi(yearStr);
			Composer composer(name, year);
			list.insert(composer);
		}
	}
	inFile.close();
}
/*
1. This method a reference of LinkedList object
2. It returns true/ false
3. It displays the list of options to user
*/
bool options(LinkedList<Composer>& list)
{
	if (!list.isEmpty())
	{
		char option;
		cout << "Enter 's' to search, 'r' to remove, 'd' to display, or 'e' to exit: ";
		cin >> option;
		while (cin.fail())
		{
			cout << "Inappropriate choice" << endl;
			cout << "Enter 's' to search, 'r' to remove, 'd' to display, or 'e' to exit: ";
			cin >> option;
		}
		switch (option)
		{
		case 's':
			search(list);
			break;
		case 'r':
			remove(list);
			break;
		case 'd':
			cout << endl;
			list.printList();
			cout << endl;
			break;
		case 'e':
			return false;
		default:
			cout << "Inappropriate choice" << endl;
		}
		return true;
	}
	else
	{
		cout << "The list is empty. Program has stopped !" << endl;
		return false;
	}
}
/*
1. This method accepts reference of LinkedList object
2. It returns nothing
3. It will call find() method of LinkedList object
*/
void search(LinkedList<Composer>& list) 
{
	string name;
	cout << "Enter a composer's name to search for: ";
	cin.ignore();
	getline(cin, name);
	Composer composer(name, 0);
	bool doesExist = list.find(composer);
	if (doesExist)
		cout <<endl<< setw(10) << " " << name << " was found in the list" << endl<<endl;
	else
		cout <<endl<< setw(10) << " " << name << " was not found in the list" << endl<<endl;
}
/*
1. This method accepts reference of LinkedList object
2. It returns nothing
3. It will call remove(const T) method of LinkedList object
*/
void remove(LinkedList<Composer>& list)
{
	string name;
	cout << "Enter a composer's name to remove for: ";
	cin.ignore();
	getline(cin, name);
	Composer composer(name, 0);
	bool removed = list.remove(composer);
	if (removed)
		cout <<endl<< setw(10) << " " << name << " was successfully removed from the list" << endl<<endl;
	else
		cout <<endl<< setw(10) << " " << name << "was not found in the list when attempting to remove" << endl<<endl;
}
