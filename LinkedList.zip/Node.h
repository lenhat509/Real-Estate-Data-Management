/*
March, 12th, 2020
For this assignment we will be creating a multi-file project
in which we implement our own templated linked list and
use it to create a simple list of composers
*/
#ifndef NODE_H
#define NODE_H
template<class T>
class Node {
public:
	T value;
	Node<T>* next;
	Node();
};
//default constructor
template<class T>
Node<T>::Node() {
	next = nullptr;
}

#endif 

