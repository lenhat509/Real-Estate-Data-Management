//
//  main.cpp
//  AVL_Tree
//
//  Created by Nicholas Zhang on 6/4/20.
//  Copyright © 2020 Nicholas Zhang. All rights reserved.
//

#include <iostream>
#include <cassert>
#include <set>
#include <vector>
#include "BST.h"
using namespace std;

void swap1(char*&, char*&);

int main() {
    srand(time(0));
    BST<int> tree;
    multiset<int> test;
    
    vector<int> e;
    
    for (int i = 0; i < 2; i++) {
        int val = rand() % 10;
        
        tree.addNode(val);
        test.insert(val);
        
        cout << "inserting " << val <<  ": ";
        //tree.print();
        cout << endl;
        e.push_back(val);
    }
    
    return 0;
    
    cout << endl;
    int cnt = 0;
    for (int i : e) {
        tree.deleteNode(i);
        
        cout << "count(" << cnt++ << ")";
        cout << "deleting " << i << ": ";
        tree.print();
        cout << endl;
    }
    
    cout << "Printing tree: " << endl;
    tree.print();
    
    for (int i = 0; i < 1000; i++) {
       
        int val = rand() % 10000;
        int* res = tree.getNextLargest(val);
        
        auto it = test.upper_bound(val);
        int* res_test = (it == test.end() ? nullptr : new int (*it));
        
        if (res && !res_test) {
            cout << *res << " vs nullptr" << endl;
            assert(false);
        }
        else if (!res && res_test) {
            cout << "nullptr vs " << *res_test << endl;
            assert(false);
        }
        else if (res && res_test) {
            cout << *res << " vs " << *res_test << endl;
            assert(*res == *res_test);
        } else {
            cout << "nullptr vs nullptr" << endl;
        }
        
        tree.deleteNode(e.back());
        test.erase(test.find(e.back()));
        
        e.pop_back();
    }
}

