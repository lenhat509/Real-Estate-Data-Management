//
//  BST.h
//  Quiz2Studying
//
//  Created by Kevin Jin on 6/4/20.
//  Copyright © 2020 Kevin Jin. All rights reserved.
//

#ifndef BST_h
#define BST_h

#include "Node.h"
#include <iostream>
using namespace std;

template<class T>
class BST {
private:
    Node<T>* root;
    
    Node<T>* getNodeFor(T, Node<T>*);
    void addNode(T, Node<T>*, Node<T>*);
    bool deleteNode(T, Node<T>*, Node<T>*);
    void print(Node<T>*);
    
    void destructor(Node<T>*);
    
    Node<T>* getNextLargest(T, Node<T>*);
    
public:
    BST();
    ~BST();
    
    void print();
    void addNode(T);
    
    T* getNodeFor(T);
    bool deleteNode(T);
    bool isEmpty();
};

template<class T>
BST<T>::BST() {
    root = nullptr;
}

template<class T>
void BST<T>::destructor(Node<T>* current) {
    if (!current) return;
    
    destructor(current->lft);
    destructor(current->rht);
    
    if (current != root)
        delete current;
}

template<class T>
BST<T>::~BST() {
    destructor(root);
}

// public version
template<class T>
T* BST<T>::getNodeFor(T data) {
    Node<T>* result = getNodeFor(data, root);
    return (result ? new T(result->data) : nullptr);
}

// private version
template<class T>
Node<T>* BST<T>::getNodeFor(T data, Node<T>* current) {
    if (current == nullptr || current->data == data)
        return current;
    else if (current->data < data)
        return getNodeFor(data, current->right);
    else if (current->data > data)
        return getNodeFor(data, current->left);
}

template<class T>
void BST<T>::addNode(T data, Node<T>* current, Node<T>* previous) {
    if (current == nullptr) {
        if (data >= previous->data)
            previous->rht = new Node<T>(data, previous, nullptr, nullptr);
        else
            previous->lft = new Node<T>(data, previous, nullptr, nullptr);
    } else if (data >= current->data)
        addNode(data, current->rht, current);
    else if (data < current->data)
        addNode(data, current->lft, current);
}

template<class T>
void BST<T>::addNode(T data) {
    if (root == nullptr)
        root = new Node<T>(data, nullptr, nullptr, nullptr);
    else if (data >= root->data)
        addNode(data, root->rht, root);
    else if (data < root->data)
        addNode(data, root->lft, root);
}

template<class T>
bool BST<T>::deleteNode(T data, Node<T>* current, Node<T>* previous) {
    cout << "delete node " << data << ", checking " << current->data << endl;
    if (current == nullptr)
        return false;
    else if (current->data == data) {
        // case 1: current has no children
        // case 2: current has 1 child
        // case 3: current has 2 children
        
        Node<T> val = Node<T>(data, 0, 0, 0);
        if (current == root && (!current->lft || !current->rht)) {
            current->up = &val;
        }
        
        if (current->lft == nullptr && current->rht == nullptr) {
            if (current == current->up->rht)
                current->up->rht = current->rht;
            else
                current->up->lft = current->rht;
        }
        else if (current->lft == nullptr && current->rht != nullptr) {
            current->rht->up = current->up;
            if (current == current->up->rht)
                current->up->rht = current->rht;
            else
                current->up->lft = current->rht;
        }
        else if (current->rht == nullptr && current->lft != nullptr) {
            current->lft->up = current->up;
            if (current == current->up->rht)
                current->up->rht = current->lft;
            else
                current->up->lft = current->lft;
        } else {
            
            // assuming that both right and left are filled
            // two cases: 1) cur->left->right exists, 2) doesn't
            Node<T>* temp = current;
            Node<T>* traverseNode = current->lft;
            
            int count = 0;
            while (traverseNode != nullptr) {
                temp = traverseNode;
                traverseNode = traverseNode->rht;
                ++count;
            }
            
            current->data = temp->data;
            
            deleteNode(temp->data, temp, temp->up);
            
            return true;
        }
 
        if (current == root) {
            root = current->up->rht;
            if (root)
                root->up = nullptr;
        }
        
        current->rht = current->lft = nullptr;
        val.rht = val.lft = nullptr;
        
        delete current;
        return true;
        
    } else if (data >= current->data)
        return deleteNode(data, current->rht, current);
    else if (data < current->data)
        return deleteNode(data, current->lft, current);
    
    return false;
}

template<class T>
bool BST<T>::deleteNode(T data) {
    cout << "deleting " << data << endl;
    if (root == nullptr)
        return false;
    else
        return deleteNode(data, root, 0);

    return false;
}

template<class T>
void BST<T>::print(Node<T>* current) {
    if (!current) return;
    
    print(current->lft);
    cout << current->data << " ";
    print(current->rht);
}

template<class T>
void BST<T>::print() {
    print(root);
}

template<class T>
bool BST<T>::isEmpty() {
    return (!root ? true : false);
}

#endif /* BST_h */
