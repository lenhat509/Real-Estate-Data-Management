//
//  Node.h
//  Quiz2Studying
//
//  Created by Kevin Jin on 6/4/20.
//  Copyright © 2020 Kevin Jin. All rights reserved.
//

#ifndef Node_h
#define Node_h

template<class T>
struct Node {
    Node();
    Node(T, Node<T>*, Node<T>*, Node<T>*);
    ~Node();
    T data;
    Node<T>* up;
    Node<T>* lft;
    Node<T>* rht;
};

template<class T>
Node<T>::Node() {
    data = T();
    up = lft = rht = nullptr;
}

template<class T>
Node<T>::Node(T data, Node<T>* up, Node<T>* lft, Node<T>* rht) {
    this->data = data;
    this->up = up;
    this->lft = lft;
    this->rht = rht;
}

template<class T>
Node<T>::~Node() {
    delete lft;
    delete rht;
}

#endif /* Node_h */
